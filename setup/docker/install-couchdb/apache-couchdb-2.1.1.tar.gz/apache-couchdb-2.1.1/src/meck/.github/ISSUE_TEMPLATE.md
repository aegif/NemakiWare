[Short description of problem here]

## Reproduction Steps

1. [First Step]
2. [Second Step]
3. [Other Steps...]

## Expected behavior

[Describe expected behavior here]

## Observed behavior

[Describe observed behavior here]

## Versions

* **Meck version:** [Enter Meck version here]
* **Erlang version:** [Enter Erlang version here]

[Add any other environment or test framework related information here, such as
what OS you are using and how Erlang is installed]
