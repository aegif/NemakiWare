Apache CouchDB BUGS
===================

Visit our issue tracker:

    https://github.com/apache/couchdb/issues

You can use this to report bugs, request features, or suggest enhancements.

Our JIRA system no longer accepts new issues, but may have important historical
information:

    https://issues.apache.org/jira/browse/CouchDB
