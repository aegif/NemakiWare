This repository follows the same contribution guidelines as the
main Apache CouchDB contribution guidelines:

https://github.com/apache/couchdb/blob/master/CONTRIBUTING.md
