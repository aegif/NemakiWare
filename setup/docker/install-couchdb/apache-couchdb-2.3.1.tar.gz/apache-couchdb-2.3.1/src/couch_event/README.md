# Couch Event Notifications

The replacement for couch\_db\_update and related code.
